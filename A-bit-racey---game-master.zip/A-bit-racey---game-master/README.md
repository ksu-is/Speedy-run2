# A-bit-racey---game
A game in which score is increased by the number of dodged obstacles just by the use of arrow keys. It is build on Python using Pygame.
![ezgif com-video-to-gif](https://cloud.githubusercontent.com/assets/15019864/17464870/3ecfe7b4-5d06-11e6-8e6b-3e9da2f6ee08.gif)
